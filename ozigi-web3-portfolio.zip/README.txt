OZIGI WEB3 PORTFOLIO

Files:
- index.html — the complete website. No paid software or framework is required.

FREE PUBLISHING:
1. Create a GitHub account at github.com if you don't have one.
2. Create a new repository named: olinkstiyc.github.io
3. Upload index.html to the repository.
4. In the repository, open Settings > Pages.
5. Choose "Deploy from a branch", select the main branch and root folder, then save.
6. Your site should become available at:
   https://olinkstiyc.github.io

If that address is unavailable because your GitHub username differs, GitHub will show the correct Pages address.

EDITING:
Open index.html in any text editor if you want to change the wording, links, or design.
The X button already points to: https://x.com/olinkstiyc
